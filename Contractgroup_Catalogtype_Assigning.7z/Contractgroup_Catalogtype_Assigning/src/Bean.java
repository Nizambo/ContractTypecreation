
public class Bean {
    private String AccountNumber;
	private String CatalogType;
	private String ContractGroup;
	
	public String getCatalogType() {
		return CatalogType;
	}
	public void setCatalogType(String catalogType) {
		CatalogType = catalogType;
	}
	public String getContractGroup() {
		return ContractGroup;
	}
	public void setContractGroup(String contractGroup) {
		ContractGroup = contractGroup;
	}
	public String getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
	}
	
	
}
