import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.gargoylesoftware.htmlunit.javascript.host.Console;

public class UpdateAction {

	public static boolean loginQA(WebDriver driver){
	    driver.get("https://cdm-webapp-qa.nike.net/CDM_Web/login.do");
	    driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[2]/span[2]/input")).sendKeys("csargu");
		driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[3]/span[2]/input")).sendKeys("roter!solly");		
		driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[4]/input")).click();
		
		return true;
	}

	public static boolean loginProd(WebDriver driver){
	    driver.get("https://cdmwebapp.nikeprd.net/admin/login.seam");
	    driver.findElement(By.xpath("//*[@id=\"login:username\"]")).sendKeys("nizamudeen.jeelani@nike.com");
		driver.findElement(By.xpath(".//*[@id=\"login:password\"]")).sendKeys("raDruw#69req");		
		driver.findElement(By.xpath("//*[@id=\"login:j_id8_body\"]/div[2]/input")).click();
		
		return true;
	}
	
	public static void createCatalog(WebDriver driver, Logger logger){
		
		try {
			
				
		System.out.println("Inside create catalog");
		driver.findElement(By.xpath(".//*[@id='catalogMenu']/select/option[2]")).click();
		Thread.sleep(3000);
				
			
				
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	}
	

	}


		
		