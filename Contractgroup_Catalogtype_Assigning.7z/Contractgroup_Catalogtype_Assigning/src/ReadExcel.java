import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.logging.Logger;

//import com.gargoylesoftware.htmlunit.javascript.host.Set;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class ReadExcel {
	public static List<Bean> readExcel(File xlfile) throws BiffException,IOException {
	
		Logger  logger = Logger.getLogger("MyLog");
		//FileInputStream fs = new FileInputStream(new File("D:\\Selenium\\Excel\\Master_catalog.xls"));
		FileInputStream fs = new FileInputStream(xlfile);
		System.out.println(xlfile.getAbsolutePath());
		Workbook wb = Workbook.getWorkbook(fs);
		List<Bean> catalogList=new ArrayList<Bean>();
		LinkedHashSet catalog_id = new LinkedHashSet();
	//	LinkedHashSet catalog_type= new LinkedHashSet();
		// TO get the access to the sheet
		Sheet sh = wb.getSheet("Sheet1");

		// To get the number of rows present in sheet
		int totalNoOfRows = sh.getRows();

		// To get the number of columns present in sheet
		int totalNoOfCols = sh.getColumns();

		for (int row = 0; row < totalNoOfRows; row++) {
			
			if(row==0)
			{
				continue;
			}
			Bean c=new Bean();
			for (int col = 0; col < totalNoOfCols; col++)
				{
				System.out.print(sh.getCell(col, row).getContents() + "\t");
				catalog_id.add(sh.getCell(col, row).getContents());
				
				
				
				if(col==0)
				{
					
					c.setAccountNumber(sh.getCell(col, row).getContents());
					
				}

				
				
			//	catalog_type.add(sh.getCell(col+1,row).getContents());
			//	System.out.print(sh.getCell(col+1, row).getContents() + "\t");
			}
			catalogList.add(c);
		}
		return catalogList;
	}
}
				
		
				
	